module.exports = {
    MONGODB: 'mongodb+srv://giogrand:GIOgio85@cluster0-10rgy.mongodb.net/test?retryWrites=true&w=majority',
    SECRET_KEY: 'il casper'
}